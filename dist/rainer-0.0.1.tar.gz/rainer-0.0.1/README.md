# RAINER
Resting stAte tIme and frequeNcy analyzER (RAINER)



install scipy, nibabel, matplotlib